#Hello. These files are all private to Source Iraq Thun. 
#In short, there are files registered for Source, another group. 
#You do not need to write a file from the beginning for the sake of rights, 
#and there are complete files. Thank you for installing Iraq Thun. 
#Our channel is here: https://t.me/tele_thon

import re
import random
import asyncio
from telethon import events
from userbot import CMD_HELP
from collections import deque
from ..utils import admin_cmd, sudo_cmd, edit_or_reply

@borg.on(admin_cmd(pattern="think$", outgoing=True))
@borg.on(sudo_cmd(pattern="think$",allow_sudo = True))
async def _(event):
	event = await edit_or_reply(event , "think")
	deq = deque(list("🤔🧐🤔🧐🤔🧐"))
	for _ in range(48):
		await asyncio.sleep(0.1)
		await event.edit("".join(deq))
		deq.rotate(1)
		
@borg.on(admin_cmd(pattern=r"lmao$"))
@borg.on(sudo_cmd(pattern="lmao$",allow_sudo = True))
async def _(event):
	event = await edit_or_reply(event ,"lmao")
	deq = deque(list("😂🤣😂🤣😂🤣"))
	for _ in range(48):
		await asyncio.sleep(0.1)
		await event.edit("".join(deq))
		deq.rotate(1)

    
@borg.on(admin_cmd(pattern=r"nothappy$"))
@borg.on(sudo_cmd(pattern="noathappy$",allow_sudo = True))
async def _(event):
	event = await edit_or_reply(event ,"nathappy")
	deq = deque(list("😁☹️😁☹️😁☹️😁"))
	for _ in range(48):
		await asyncio.sleep(0.4)
		await event.edit("".join(deq))
		deq.rotate(1)
		
@borg.on(admin_cmd(outgoing=True, pattern="clock$"))
@borg.on(sudo_cmd(pattern="clock$",allow_sudo = True))
async def _(event):
	    event = await edit_or_reply(event , "clock")
	    deq = deque(list("🕙🕘🕗🕖🕕🕔🕓🕒🕑🕐🕛"))
	    for _ in range(48):
		    await asyncio.sleep(0.1)
		    await event.edit("".join(deq))
		    deq.rotate(1)
        
@borg.on(admin_cmd(pattern=r"muah$"))
@borg.on(sudo_cmd(pattern="muah$",allow_sudo = True))
async def _(event):
	event = await edit_or_reply(event ,"muah")
	deq = deque(list("😗😙😚😚😘"))
	for _ in range(48):
		await asyncio.sleep(0.1)
		await event.edit("".join(deq))
		deq.rotate(1)	
    
@borg.on(admin_cmd(pattern="heart$"))
@borg.on(sudo_cmd(pattern="heart$",allow_sudo = True))
async def _(event):
	event = await edit_or_reply(event ,"heart")
	deq = deque(list("❤️🧡💛💚💙💜🖤"))
	for _ in range(48):
		await asyncio.sleep(0.1)
		await event.edit("".join(deq))
		deq.rotate(1)        
        
		
@borg.on(admin_cmd(pattern="gym$", outgoing=True))
@borg.on(sudo_cmd(pattern="gym$",allow_sudo = True))
async def _(event):
	event = await edit_or_reply(event ,"gym")
	deq = deque(list("🏃‍🏋‍🤸‍🏃‍🏋‍🤸‍🏃‍🏋‍🤸‍"))
	for _ in range(48):
		await asyncio.sleep(0.1)
		await event.edit("".join(deq))
		deq.rotate(1)
    
@borg.on(admin_cmd(pattern=f"earth$", outgoing=True))
@borg.on(sudo_cmd(pattern="earth$",allow_sudo = True))
async def _(event):
	event = await edit_or_reply(event ,"earth")
	deq = deque(list("🌏🌍🌎🌎🌍🌏🌍🌎"))
	for _ in range(48):
		await asyncio.sleep(0.1)
		await event.edit("".join(deq))
		deq.rotate(1)
    
@borg.on(admin_cmd(outgoing=True, pattern="moon$"))
@borg.on(sudo_cmd(pattern="moon$",allow_sudo = True))
async def _(event):
	    event = await edit_or_reply(event ,"moon")
	    deq = deque(list("🌗🌘🌑🌒🌓🌔🌕🌖"))
	    for _ in range(48):
		    await asyncio.sleep(0.1)
		    await event.edit("".join(deq))
		    deq.rotate(1)
        
@borg.on(admin_cmd(pattern=f"smoon$", outgoing=True))
@borg.on(sudo_cmd(pattern="smoon$",allow_sudo = True))
async def _(event):
    event = await edit_or_reply(event ,"smoon")
    animation_interval = 0.1
    animation_ttl = range(0, 101)
    await event.edit("smoon..")
    animation_chars = [

            "🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗",
            "🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘",    
            "🌑🌑🌑🌑🌑\n🌕🌕🌕🌕🌕\n🌑🌑🌑🌑🌑\n🌕🌕🌕🌕🌕\n🌑🌑🌑🌑🌑",
            "🌒🌒🌒🌒🌒\n🌖🌖🌖🌖🌖\n🌒🌒🌒🌒🌒\n🌖🌖🌖🌖🌖\n🌒🌒🌒🌒🌒",
            "🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓",
            "🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔",
            "🌕🌕🌕🌕🌕\n🌑🌑🌑🌑🌑\n🌕🌕🌕🌕🌕\n🌑🌑🌑🌑🌑\n🌕🌕🌕🌕🌕",
            "🌖🌖🌖🌖🌖\n🌒🌒🌒🌒🌒\n🌖🌖🌖🌖🌖\n🌒🌒🌒🌒🌒\n🌖🌖🌖🌖🌖"
        ]
    for i in animation_ttl:
            await asyncio.sleep(animation_interval)
            await event.edit(animation_chars[i % 8])
            
@borg.on(admin_cmd(pattern=f"tmoon$", outgoing=True))
@borg.on(sudo_cmd(pattern="tmoon$",allow_sudo = True))
async def _(event):
    event = await edit_or_reply(event ,"tmoon")
    animation_interval = 0.1
    animation_ttl = range(0, 117)
    await event.edit("tmoon")
    animation_chars = [

            "🌗",
            "🌘",    
            "🌑",
            "🌒",
            "🌓",
            "🌔",
            "🌕",
            "🌖",
            "🌗",
            "🌘",    
            "🌑",
            "🌒",
            "🌓",
            "🌔",
            "🌕",
            "🌖",
            "🌗",
            "🌘",    
            "🌑",
            "🌒",
            "🌓",
            "🌔",
            "🌕",
            "🌖",
            "🌗",
            "🌘",    
            "🌑",
            "🌒",
            "🌓",
            "🌔",
            "🌕",
            "🌖"
        ]
    for i in animation_ttl:
            await asyncio.sleep(animation_interval)
            await event.edit(animation_chars[i % 32])
