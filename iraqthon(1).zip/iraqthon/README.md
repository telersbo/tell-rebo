[![iraqthon](https://telegra.ph/file/122a7103f64e88bd97ae4.jpg)](https://heroku.com/deploy)

# Welcome to BOT Iraq Thun Thank you for choosing us. Our channel is here: https://t.me/tele_thon

[![Deploy To Heroku iraqthon](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
<p align="center">
  <a href="https://github.com/klanrali/iraqthon/fork">
    <img src="https://img.shields.io/github/forks/klanrali/plus.telethon?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/klanrali/iraqthon">
    <img src="https://img.shields.io/github/stars/klanrali/iraqthon?style=social">
  </a>
</p>

### Join [here](https://t.me/tele_thon) for updates and tuts and [here](https://t.me/klanraloosh) for discussion and bugs


- Only two of the environment variables are mandatory.
- This is because of `telethon.errors.rpc_error_list.ApiIdPublishedFloodError`

    - `APP_ID`:   You can get this value from https://my.telegram.org
    - `API_HASH`:   You can get this value from https://my.telegram.org
- The userbot will not work without setting the mandatory vars.
